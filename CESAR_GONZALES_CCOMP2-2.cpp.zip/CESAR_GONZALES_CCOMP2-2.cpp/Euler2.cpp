#include <iostream>

using namespace std;

int main() {
    int numero1 = 1, numero2 = 2, fib = 0, suma = 0;

    while (numero2 <= 4000000) {
        if (numero2 % 2 == 0) {
            suma += numero2;
        }
        fib = numero1 + numero2;
        numero1 = numero2;
        numero2 = fib;
    }
    cout << suma << endl;
    return 0;
}